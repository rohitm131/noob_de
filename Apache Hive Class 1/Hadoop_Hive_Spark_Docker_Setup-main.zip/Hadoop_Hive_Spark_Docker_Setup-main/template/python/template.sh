#!/bin/bash

sh /submit.sh
